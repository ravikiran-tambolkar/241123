import unittest
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

class PythonOrgSearch(unittest.TestCase):

     # initialization of webdriver
    def setUp(self):
        self.driver = webdriver.Chrome()
    
    def test_landed_on_same_page_expected(self):
        driver = self.driver
        driver.get("https://gor-pathology.web.app/")
        
        # Wait for the element to be present
        gor_element = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, 'div.MuiPaper-root'))
        )

        gor_text = gor_element.text
        assert "GOR" in gor_text, "#LANDED ON WRONG PAGE#"
    
    def test_invalid_login(self):
        driver = self.driver
        driver.get("https://gor-pathology.web.app/")

        # Assuming there's a login button that you need to click to go to the login page
        login_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, 'FORM.jss107 button[type=submit]'))
        )
        login_button.click()

        # Assuming there are input fields for username (email) and password
        username_input = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, 'input[name=email]'))
        )
        password_input = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, 'input[name=password]'))
        )

        # Enter incorrect credentials
        username_input.send_keys("invalid@kennect.io")
        password_input.send_keys("IncorrectPassword123")

        # Submit the login form
        login_form_submit_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, 'form.jss9 button[type=submit]'))
        )
        login_form_submit_button.click()

        # Assuming there's an element indicating an error message (adjust the selector accordingly)
        error_message = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, '//*[contains(text(), "Invalid credentials")]'))
        )

        # Assert that the error message is present, indicating a failed login
        assert "Invalid credentials" in error_message.text, "Login should fail with invalid credentials"
    
    def test_login_with_credentials(self):
        driver = self.driver
        driver.get("https://gor-pathology.web.app/")

        # Assuming there's a login button that you need to click to go to the login page
        login_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, 'form.jss9 button[type=submit]'))
        )
        login_button.click()

        # Assuming there are input fields for username (email) and password
        username_input = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, 'input[name=email]'))
        )
        password_input = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, 'input[name=password]'))
        )

        # Enter the credentials
        username_input.send_keys("test@kennect.io")
        password_input.send_keys("Qwerty@1234")

        login_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, 'form.jss9 button[type=submit]'))
        )
        login_button.click()

        # Instead of checking for a specific success message, you can check for a change in the URL, title, or any other indication of a successful login
        # For example, you can check that the URL has changed to the dashboard page
        WebDriverWait(driver, 10).until(
            EC.url_contains("dashboard")
        )

    def test_ui_after_successful_login(self):
        driver = self.driver
        driver.get("https://gor-pathology.web.app/")

        # Assuming there's a login button that you need to click to go to the login page
        login_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, 'form.jss9 button[type=submit]'))
        )
        login_button.click()

        # Assuming there are input fields for username (email) and password
        username_input = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, 'input[name=email]'))
        )
        password_input = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, 'input[name=password]'))
        )

        # Enter the credentials
        username_input.send_keys("test@kennect.io")
        password_input.send_keys("Qwerty@1234")

        # Submit the login form
        login_form_submit_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, 'form.jss9 button[type=submit]'))
        )
        login_form_submit_button.click()

        # Wait for the UI element after successful login (ul.MuiList-root.MuiList-padding)
        ui_element = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, 'ul.MuiList-root.MuiList-padding'))
        )

        # Assert that the UI element is present, indicating a successful login
        assert ui_element.is_displayed(), "Expected UI element not found after login"

    def test_add_todo_button(self):
        driver = self.driver
        driver.get("https://gor-pathology.web.app/")

        # Assuming there's a login button that you need to click to go to the login page
        login_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, 'form.jss9 button[type=submit]'))
        )
        login_button.click()

        # Assuming there are input fields for username (email) and password
        username_input = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, 'input[name=email]'))
        )
        password_input = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, 'input[name=password]'))
        )

        # Enter the credentials
        username_input.send_keys("test@kennect.io")
        password_input.send_keys("Qwerty@1234")

        # Submit the login form
        login_form_submit_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, 'form.jss9 button[type=submit]'))
        )
        login_form_submit_button.click()


        button_to_click = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, 'div.jss72 span.MuiButton-label'))
        )
        button_to_click.click()

        todo_input = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, 'input#outlined-add-todo-input'))
        )
        todo_input.send_keys("ravikiran testing")

        save_todo_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, 'form.jss101 button.MuiButtonBase-root'))
        )
        save_todo_button.click()

        success_message = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, 'div.MuiAlert-message'))
        )

        # Assert that the success message is present and contains the expected text
        assert success_message.is_displayed() and "Todo added successfully!" in success_message.text, "Todo not added successfully"


    # cleanup method called after every test performed
    def tearDown(self):
        self.driver.close()
 
# execute the script
if __name__ == "__main__":
    unittest.main()